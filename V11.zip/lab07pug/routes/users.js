var express = require('express');
var sha1 = require('sha1');
var router = express.Router();
var User = require('../utils/db.js')
var jsonwebtoken = require('jsonwebtoken');

//Ok
// Pobieranie całej kolekcji - lista wszystkich użytkowników w bazie
router.get('/', function(req, res) {
  User.find(function (err, data) {
    if (err) return console.error(err);
    console.log(data);
    res.render('uzytkownicy',{ data });
  })
});
//Ok
// Pobieranie wybranego uzytkownika z kolekcji
router.get('/:id', function(req, res, next) {
	User.findById(req.params.id, function (err, doc) {
	if (err) return next(err);
	res.json(doc);
	});
});
// Działa tylko w x-www-form-urlencoded
// Dodawanie nowego uzytkownika do kolekcji
router.post('/', function(req, res, next) {
	User.create(req.body, function (err, doc) {
	if (err) return next(err);
	// console.log(JSON.stringify(doc));
	res.json(doc);
	});
});
// Dziala tylko w x-www-form-urlencoded
// Aktualizacja wybranego uzytkownika
router.put('/:id', function(req, res, next) {
	User.findByIdAndUpdate(req.params.id, req.body, function (err, doc) {
	if (err) return next(err);
	res.json(doc);
	});
});
//Ok
// Usuwanie wszystkich dokumentów z kolekcji
router.delete('/usunUzyt', function(req, res, next) {
	User.remove({}, function (err, writeRes) {
	if (err) return next(err);
	res.send(writeRes);
	});
});
//Ok
// Usuwanie wybramego uzytkownika z kolekcji 
router.delete('/usun/:id', function(req, res, next) {
	User.findByIdAndRemove(req.params.id, function (err, doc) {
	if (err) return next(err);
	res.json(doc);
	});
});

router.get('/usun/:id', function(req, res, next) {
	User.findByIdAndRemove(req.params.id, function (err, doc) {
	if (err) return next(err);
	res.redirect('/uzytkownicy');
	});
});

// resetowanie zawartości kolekcji użytkowników
router.get('/reset', function(req, res, next) {
  User.remove({}, function (err) {
    if (err) return handleError(err);
    var admin = new User({"username":"admin", "password":sha1("stud234"), "admin": true, "active": true});
    var asdf = new User({"username":"asdf", "password":sha1("asdf") ,"active": false, "email": "web20@t.pl"});
    // create two users: 'admin' and 'asdf'
    admin.save((err,data)=>{
      if (err) return console.error(err);
      asdf.save(function(err,data2) {
        if (err) return console.error(err);
        res.send("<h3>Utworzeni użytkownicy:</h3>" + data + " <br> " + data2);
      })
    });
  });
});

module.exports = router;