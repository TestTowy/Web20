var express = require('express');
var router = express.Router();
var session = require('express-session');
var passport = require('passport');

var bodyParser = require('body-parser');
var mongo = require('mongodb').MongoClient;
var objectId = require('mongodb').ObjectID;
var mongoose = require('mongoose');
//var mongojs = require('mongojs');
var assert = require('assert');
var url = 'mongodb://DawidMDB:Test123@ds022228.mlab.com:22228/dawidmdb';

LocalStrategy = require('passport-local').Strategy;
var tTransporter = require('../utils/transport').tTransporter;
var User = require('../utils/db.js');
var sha1 = require('sha1');
//var getTestMessageUrl = require(’../utils/tTransport).getTestMessageUrl;

//Strona startowa + dane z bazy
router.get('/', function(req, res, next) {
  var resultArray = [];
  mongo.connect(url, function(err, db) {
    assert.equal(null, err);
    var cursor = db.db('dawidmdb').collection('Choinki').find();
    cursor.forEach(function(doc, err) {
      assert.equal(null, err);
      resultArray.push(doc);
    }, function() {
      db.close();
      res.render('index', {Choinki: resultArray});
    });
  });
});
/*Dane o użytkowniku zalogowanym*/
// inforamcja o kilku obiektach przechowujących dane zalogowanego użytkownika
router.get('/zalogowany', function(req, res) {
  var dane = {
    user: req.user,
    passport: req.session.passport,
    log_info: res.locals.logInfo
  };
  res.render('zalogowany', dane);
});
/*Dane o Sesji*/
//Może cos uzyje
// informacje o sesji użytkownika
router.get('/sesja', function(req, res, next) {
  if(req.session.odwiedziny) {
    req.session.odwiedziny++;
  } else {
    req.session.odwiedziny = 1;
  }
  var dane = {
    idSesji: req.session.id,
    odwiedziny: req.session.odwiedziny,
    ciasteczko: req.session.cookie,
    data: req.session.cookie.data,
    passport: req.session.passport
  };
  res.render('sesja', dane);
});

/*Rejestracja*/
//Wyswietlenie formularza do rejestracji
router.get('/Zarejestruj', function(req, res, next) {
  res.render('Zarejestruj');
});
//Tworzenie +  wyslanie emaila
router.post('/rejestracja', function(req, res) {
      let mailOptions = {
      from: '"MyApp Team" <web20@t.pl>', // adres nadawcy
      to: req.body.email, // lista odbiorców
  };
  // tworzenie użytkownika i wysyłanie maila...
  var newUser = new User({"username":req.body.username, "password":sha1(req.body.password),"email": req.body.email, "active": false});
          newUser.save(function(err,data) {
          if (err) return console.error(err);
          var host = "http://localhost:3000";
          // var host2 = "http://myapp.com";
          var aL = host + '/activate/' + data._id;
          res.render('tresc', {activationLink: aL}, function(err, body){
            mailOptions.html = body;
            mailOptions.subject = 'Aktywacja konta';
            console.log(body);
            tTransporter.sendMail(mailOptions, (error, info) => {
              if (error) { return console.log(error); }
                //res.send(`<h3>Utworzony użytkownik:</h3> ${data}<br>Wiadomość o ID ${info.messageId} wysłana: ${info.response}.`);
                //res.send(`<div class="alert alert-success alert-dismissible fade show">  <button type="button" class="close" data-dismiss="alert">×</button>  <h4 class="alert-heading">Succuss!</h4> Your message has been sent successfully..  </div>`);
                res.render('Zarejestruj2', {data});
        });
      });
    });
  });
/*Aktywacja konta*///Dlaczego to nie dziala->przekierowanie do login | na zalogowanym/aktywowanym dziala ?
router.get('/activate/:id', function(req, res, next) {
  User.findByIdAndUpdate( req.params.id, { $set:{active:true} }, {new: false}, function(err, data) {
  //res.send("Aktywacja konta użytkownika: " + req.params.id + " ### " + data);
  res.render('Zaloguj2',{data});
  });
});
/*Logowanie*/
//Wyświetlanie formularza do logowania
router.get('/login', function(req, res) {
  console.log(req.message);
  res.render('Zaloguj',{ message: req.message });
});
// logowanie użytkownika
// poprawne logowanie - przekierowanie na stronę główną
// brak uwierzytelnienia - przekierowanie na strone logowania
router.post('/login',
  passport.authenticate('local',
    { session: true,
      successRedirect: '/',
      failureRedirect: '/login' }
  )
);
//Wylogowanie i przekierowanie na stronę główną
router.get('/logout', function(req, res){
  req.logout();
  res.redirect('/');
});



//Cos dziala
/*Wystlanie maila Testy*/
/*
router.get('/send-email3', function(req, res, next) {
  let mailOptions = {
    from: `"Student Web 2.0" <web20@t.pl>`, // adres nadawcy
    to: `asdf@asdf.com, jkowalski@icis.pcz.pl,dawko123455@gmail.com`, // lista odbiorców
    subject: 'Testowa wiadomość', // temat wiadomości
    text: `Treść wiadomości jako czysty tekst`, // treść wiadomości tekstowej
    // treść w HTML
    html: `<b>Treść wiadomości jak HTML</b> <p>Jakieś znaki w unicode, grecki alfabet: α, β, γ, ...</p>`
  };
  // wysyła maila dla ustawionej warstwy transportowej dla danych opcji
  tTransporter.sendMail(mailOptions, (error, info) => {
  if (error) {
  return console.log(error);
  }
  console.log('Wiadomość %s wysłana: %s', info.messageId, info.response);
  res.send('Wiadomość' + info.messageId + ' wysłana: ' + info.response);
  });
});
*/
module.exports = router;
