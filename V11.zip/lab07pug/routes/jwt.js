var express = require('express');
var sha1 = require('sha1');
var router = express.Router();
var User = require('../utils/db.js')
var jsonwebtoken = require('jsonwebtoken');
/*Token*/

router.post('/token', function(req,res){
  if(!req.body.username){
  res.status(400).send('potrzeba nazwy użytkownika');
  return;
  }
  if(!req.body.password){
  res.status(400).send('potrzeba jeszcze hasła');
  return;
  }
  User.findOne({username: req.body.username}, function(err, user){
  if(user.password==sha1(req.body.password)) {
  var token = jsonwebtoken.sign({ username: req.body.username }, 'secret');
  res.status(200).json(token);
  } else {
  res.status(401).send('błędne hasło');
  }
  });
});

/* Testy z tokenami mozna jeszcze pomyslec co zrobic*/
router.get('/algorithms', function(req, res, next) {
    console.log( JWT.getSupportedAlgorithms() );
    res.send('lista algorytmów w konsoli');
});
//tworzenie tokenu
/*
router.get('/token', function(req, res, next) {
    var header = '{"typ":"JWT","alg":"HS256"}';
    var payload2 = {"sub": "stud234", "exp":"1546300799","name":"Dawid Chwastek"};

    var jwt = new JWT(); // tworzymy instancję jwt, domyślnie jest algorytm HS256
    jwt.setAlgorithm('HS384');
    jwt.setSecret('secret'); // ustawiamy sekret
    jwt.sign(payload2, function (err, data) {  // podpisujemy JWT
    if (err) console.log(err);
    //console.log(data);
    res.render('index', { token2: data });
    });
    //res.send('cały token wyświetlony w konsoli');
});
*/
//Deszyfracja/odczyt tokenu
/*
router.get('/weryfikacja', function(req, res, next) {

    var token = [
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJKb2huQmVhbiIsImlzcyI6Impva2UuY29tIiwiaW5mbyI6InZlcnkgZnVubnkiLCJpYXQiOjE1NDE5MzQwMDB8._axoOgvOUhXjTHHrK7GvNnoWc88pIeKFqSp31uobXOI',
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJzdHVkZW50d2ViMjAiLCJleHAiOjQ2OTc2MDc2MDAsImluZm8iOiJUbyBqdcW8IG9zdGF0bmkgc2VtZXN0ci4iLCJpYXQiOjE1NDE5MzQwMDB9.emLK6U5AUX5G6bg3idnQnHTw_vyA4hCLIyP3b9522I',
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJqYW1lczAwNyIsImlzcyI6InNpcy5nb3YudWsiLCJuYW1lIjoiQWdlbnQgSmFtZXMgQm9uZCIsImlhdCI6MTU0MTkzNDAwMH1.5t_YKsDDTTlyH2vUXmgv6l5LGZem_jTq64oHm7HuBvs',
        'sd.s.sadsadsa' ];
    var jwt = new JWT(); // tworzymy instancję jwt, domyślnie jest algorytm HS256
    jwt.setSecret('abcd1234'); // ustawiamy sekret
        
    for (var p in token) {
        jwt.verify(token[p], function (err, data) { // weryfikujemy JWT
            if (err){console.log(err)} else {res.render('index', { test: data })}
            console.log(data); // zdekodowany i zweryfikowany JWT w konsoli
            ;
        });}
    //res.send('zweryfikowany token wyświetlony w konsoli');
});
*/

module.exports = router;