var session = require('express-session');
var User = require('./db');
var passport = require('passport');
LocalStrategy = require('passport-local').Strategy;

module.exports = function(app) {

  app.use(session({
    secret: 'Test123',
    resave: false,
    saveUninitialized: false
  }));

  app.use(passport.initialize());
  app.use(passport.session());

  passport.serializeUser(function(user, done) {
    done(null, user._id);
  });

  passport.deserializeUser(function(id, done) {
    User.findById(id, function(err, user) {
      done(err, user);
    });
  });

  passport.use(new LocalStrategy(
    function(username, password, done) {
      User.findOne({ username: username }, function (err, user) {
        if (err) { return done(err); }
        if (!user) {
          //console.log('potrzeba nazwy użytkownika');
          //return done.status(400).send('potrzeba nazwy użytkownika');
          return done(null, false, { message: 'Incorrect username.' });
        }
        if (!user.validPassword(password)) {
          //return done.status(400).send('potrzeba hasła');
          return done(null, false, { message: 'Incorrect password.' });
        }
        if (!user.accountActivate()) {
          return done(null, false, { message2: 'Konto nieaktywne!.' });
        }
        return done(null, user);
      });
    }
  ));

};